<?php
	include("include/util.php");
	$firstname = htmlspecialchars($_POST["firstname"]);
	if ( empty($firstname) ) {
		header("Location: error.php?type=firstname");
		die();	
	}
	$lastname = htmlspecialchars($_POST["lastname"]);
	if ( empty($lastname) ) {
		header("Location: error.php?type=lastname");
		die();	
	}	
	$logup = htmlspecialchars($_POST["login"]);
	if ( empty($logup) ) {
		header("Location: error.php?type=logup");
		die();	
	}
	$pwdup = htmlspecialchars($_POST["password"]);
	if ( empty($pwdup) ) {
		header("Location: error.php?type=pwdup");
		die();	
	}			
	$info = $pwdup . "\n" . $firstname . "\n" . $lastname . "\n";
	$folder = dbpath() . "/$logup";
	### special for linux user
	$old = umask(0);
	###
	mkdir($folder,0777);            # 0777 is ignored on Windows
	mkdir($folder . "/notes",0777); # 0777 is ignored on Windows
	file_put_contents($folder . "/info.txt", $info);
	### special for linux user
	umask($old);
	###
	header("Location: sign_in_form.php");	
?>