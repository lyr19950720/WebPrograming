<?php
	session_start();
	include("include/util.php");
	check();
	$login = $_SESSION["login"];
	
	$title = trim(htmlspecialchars($_POST["note_title"]));
	if ( empty($title) ) {
		header("Location: error.php?type=note");
	}
	else {
		$path = dbpath() . "/$login/notes/";
/*     	$note_files = glob("$path/*");
		$total = count($note_files);
		if ( $total == 0 ) {
			$new_file = "$path/1";
		}
		else {
			$last = basename($note_files[$total-1]);
			$new_file = "$path/" . ( $last + 1 );
		} */
		file_put_contents($path . newnote(), htmlspecialchars($_POST["note_title"]) . "\nCreated " . date("Y-m-d h:ia") . "\n");
		header("Location: notes.php");
	}
?>