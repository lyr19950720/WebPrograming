<?php
	$login = $_SESSION["login"];
	
	$path = dbpath() . "/$login/notes";
	unlink("$path/" . $_POST["todo_id"]);
?>