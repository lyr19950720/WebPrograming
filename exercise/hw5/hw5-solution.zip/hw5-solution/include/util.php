<?php
function dbpath() {
	return "2doDB";
}

function check() {
	if ( ! isset($_SESSION["loggedin"]) || ! $_SESSION["loggedin"] ) {
		header("Location: error.php?type=nologin");
		die();
	}
}

function bad_login($login) {
	$folders = glob(dbpath() . "/*");
	foreach ( $folders as $folder )
		if ( $login === basename($folder) )
			return false;
	return true;
}

function bad_password($login,$password) {
	$info = file(dbpath() . "/$login/info.txt",FILE_IGNORE_NEW_LINES);
	return $password != $info[0];
}

function get_name($login) {
	$info = file(dbpath() . "/$login/info.txt",FILE_IGNORE_NEW_LINES);
	return $info[1];
}

function note_id($note_file) {
	return basename($note_file);
}

function get_title($note) {
	return $note[0];
}

function get_date($note) {
	return $note[1];
}

function newnote() {
	return date("Y") . "-" . date("m") . "-" . date("d") . "-" . date("H") . "-" . date("i") . "-" . date("s");
}

?>
