<?php
	$login = $_SESSION["login"];

	$path = dbpath() . "/$login/notes";
	$file = "$path/" . $_POST["todo_id"];
	$content = trim(htmlspecialchars($_POST["new_todo"]));
	if ( empty($content) ) {
		header("Location: error.php?type=todo");
		die();
	}
	else {
		file_put_contents($file,"\n" . $content,FILE_APPEND);		
	}
?>