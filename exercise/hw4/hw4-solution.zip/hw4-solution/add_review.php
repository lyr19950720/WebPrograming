<?php
	$name = trim(str_replace("\n"," ",$_GET["name"]));
	$organization = trim(str_replace("\n"," ",$_GET["organization"]));
	$rating = trim(str_replace("\n"," ",$_GET["rating"]));
	$review = trim(str_replace("\n"," ",$_GET["review"]));
	
	if ( empty($name) || empty($organization) || empty($rating) || empty($review) ) {
		include("add_review_error.php");
		die();
	}
	$target_dir = "moviedb/" . $_GET["film"];
	$review_number = count(glob($target_dir."/review*.txt")) + 1;
	$review_path = $target_dir . "/review" . $review_number . ".txt";
	$text = "";
	# text review
	$text = $text . str_replace("\n"," ",$_GET["review"]) . "\n";
	# rating
	$text = $text . $_GET["rating"] . "\n";
	# name of the reviewer
	$text = $text . str_replace("\n"," ",$_GET["name"]) . "\n";
	# organization of the reviewer
	$text = $text . str_replace("\n"," ",$_GET["organization"]);
	file_put_contents($review_path, $text);
	include("movie.php");
?>